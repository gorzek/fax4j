package com.java4less.rfax;

/**
 * Test Class 
 * 
 * @author 	Sagie Gur-Ari
 */
public interface FaxProducer
{
	//empty
}