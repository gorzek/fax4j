package com.java4less.rfax;

import java.awt.Image;

/**
 * Test Class 
 * 
 * @author 	Sagie Gur-Ari
 */
public class TextFaxProducer implements FaxProducer
{
	/**Class member*/
	public String text;
	/**Class member*/
	public Image pageImage;
	
	/**
	 * Test method.
	 */
	public void prepare()
	{
		//empty
	}
}