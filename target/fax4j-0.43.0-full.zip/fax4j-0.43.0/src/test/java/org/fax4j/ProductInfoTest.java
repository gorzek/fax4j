package org.fax4j;

import org.junit.Test;

/**
 * Test Class 
 * 
 * @author 	Sagie Gur-Ari
 */
public class ProductInfoTest
{
	/**
	 * Test 
	 * 
	 * @throws 	Exception
	 * 			Any exception
	 */
	@Test
	public void printProductInfoTest() throws Exception
	{
		ProductInfo.printProductInfo();
	}
}