/**
 * fax4j native layer.
 *
 * @author 	Sagie Gur-Ari
 */

// fax4jwrapper.cpp : main project file.

//fax4j dll API
#include "fax4j.h"

int main(int argc,const char* argv[])
{
	return runCLI(argc,argv);
}
