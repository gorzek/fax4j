
mvn clean install site
